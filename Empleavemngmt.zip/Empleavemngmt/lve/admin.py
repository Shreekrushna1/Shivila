from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Leavemange


@admin.register(Leavemange)
class LeavemangeAdmin(admin.ModelAdmin):
    fields = ('employee_name','employee_email','leave_type','from_leave','to_leave','details','team_lead_name')


