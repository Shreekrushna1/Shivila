from django.shortcuts import render

# Create your views here.
from .models import Leavemange
from rest_framework import viewsets
from rest_framework import permissions
from .serializers import LeavemangeSerializer


class LeavemangeViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows admission to be viewed or edited.
    """
    queryset = Leavemange.objects.all()
    serializer_class = LeavemangeSerializer
    permission_classes = [permissions.AllowAny]