from rest_framework import serializers
from .models import Leavemange


class LeavemangeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Leavemange
        fields = ['id','employee_name','employee_email','leave_type','from_leave','to_leave','details','team_lead_name']
         

