from django.db import models

# Create your models here.
from xml.dom.minidom import Document
from django.db import models
from django.conf import settings

# Create your models here.

class Leavemange(models.Model):
    
    employee_name = models.CharField(max_length=100,null=True)
    employee_email  = models.CharField(max_length=50,null=True)
    leave_type = models.CharField(max_length=50,null=True)
    from_leave = models.DateField(auto_now =False,null=False)
    to_leave = models.DateField(auto_now =False,null=False)
    details = models.CharField(max_length=200,null=False)
    team_lead_name = models.CharField(max_length=50,null=True)
    
    
    
    
    

    def __str__(self):
        
        return self.employee_name
