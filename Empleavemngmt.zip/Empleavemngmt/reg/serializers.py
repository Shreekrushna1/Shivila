from rest_framework import serializers

from .models import *


class EmployeeSerializers(serializers.ModelSerializer):

    class Meta:
        model = Employee
        fields = '__all__'



class TeamLeadSerializers(serializers.ModelSerializer):

    class Meta:
        model = TeamLead
        fields = '__all__'


class EmployeeDataSerializers(serializers.ModelSerializer):

    class Meta:
        model = EmployeeData
        fields = '__all__'

