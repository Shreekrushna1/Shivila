from django.contrib import admin
from . import models
# Register your models here.

# EMPLOYEE WORKING DATA
class EmployeeAdmin(admin.ModelAdmin):
    list_display = (    'Employee_name',
                        'morning_meeting', 
                        'afternoon_meeting',
                        'evening_meeting', 
                        'task_assigned', 
                        'TL_name', 
                        'remarks',
                        'default_date', )

admin.site.register(models.Employee,EmployeeAdmin)


# TL  DATA
class TeamLeadAdmin(admin.ModelAdmin):
    list_display = (    'TL_name',
                        'TL_Designation',
                        'TL_Email', 
                        )

admin.site.register(models.TeamLead,TeamLeadAdmin)


# EMPLOYEE DATA
class EmployeeDataAdmin(admin.ModelAdmin):
    list_display = (   'Employee_name', 
                        'TL_name', 
                        'Employee_Designation', 
                        'Employee_Emai',
                        'Joining_Date',  
                        )

admin.site.register(models.EmployeeData,EmployeeDataAdmin)


 
 
