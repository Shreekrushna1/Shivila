from django.db import models
from datetime import datetime
# Create your models here.


# TL  DATA
class TeamLead(models.Model):
    
    TL_name = models.CharField(max_length = 50 )
    TL_Designation = models.CharField(max_length =20)
    TL_Email = models.EmailField(max_length = 100)

    def __str__(self):
        return self.TL_name




# EMPLOYEE DATA    add employee
class EmployeeData(models.Model):
    Employee_name = models.CharField(max_length =20)
    TL_name = models.ForeignKey(TeamLead, on_delete = models.CASCADE)
    Employee_Designation =  models.CharField(max_length =20)
    Employee_Emai = models.EmailField(max_length = 100)
    Joining_Date = models.DateField(auto_now=False,null = True)
    
    def __str__(self):
        return self.Employee_name




# EMPLOYEE WORKING DATA
class Employee(models.Model):
    Employee_name = models.CharField(max_length =20)
    
    meeting_CHOICES = (
        ('j', 'Joined'),
        ('nj', 'Not Joined'),
    )

    morning_meeting = models.CharField(max_length=3, choices=meeting_CHOICES, default='j')
    afternoon_meeting = models.CharField(max_length=3, choices=meeting_CHOICES, default='j')
    evening_meeting = models.CharField(max_length=3, choices=meeting_CHOICES, default='j')
    task_assigned = models.CharField(max_length=500)
    project_assign_date = models.DateField(auto_now=False,null = True)
    project_delivery_date = models.DateField(auto_now=False,null = True)
    project_name = models.CharField(max_length=100,null = True)
    TL_name = models.ForeignKey(TeamLead, on_delete = models.CASCADE)
    remarks = models.CharField(max_length = 100)
    default_date = models.DateField(default=datetime.now)


    def __str__(self):
        return self.remarks



    