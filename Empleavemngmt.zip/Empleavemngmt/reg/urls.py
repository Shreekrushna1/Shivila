from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path
from rest_framework import routers

from . import views

routers= routers.DefaultRouter()
routers.register(r'Employee',views.EmployeeViewSet)
routers.register(r'TeamLead',views.TeamLeadViewSet)
routers.register(r'EmployeeData',views.EmployeeDataViewSet)
urlpatterns = [
    path('management/',include(routers.urls)),
    path('api_auth/',include('rest_framework.urls',namespace='rest_framework'))

] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)