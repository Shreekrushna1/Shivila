from django.shortcuts import render
from rest_framework import viewsets
from rest_framework import permissions
# Create your views here.
from .models import *
from .serializers import *


class EmployeeViewSet(viewsets.ModelViewSet):
    queryset =Employee.objects.all()
    serializer_class = EmployeeSerializers
    permission_classes = [permissions.AllowAny]



class TeamLeadViewSet(viewsets.ModelViewSet):
    queryset =TeamLead.objects.all()
    serializer_class = TeamLeadSerializers
    permission_classes = [permissions.AllowAny]

class EmployeeDataViewSet(viewsets.ModelViewSet):
    queryset = EmployeeData.objects.all()
    serializer_class = EmployeeDataSerializers
    permission_classes = [permissions.AllowAny]