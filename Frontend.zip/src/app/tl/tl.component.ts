import { HttpBackend, HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tl',
  templateUrl: './tl.component.html',
  styleUrls: ['./tl.component.css']
})
export class TLComponent implements OnInit {


  constructor(private http:HttpClient) { }
  obj:any;

  ngOnInit(): void {
    this.obj=this.http.get<any>("http://127.0.0.1:8000/abscent/Leavemange/").subscribe(dt=>this.obj=dt)
    console.log(this.obj);
    
  }

}
