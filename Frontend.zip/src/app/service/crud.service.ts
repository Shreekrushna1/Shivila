import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../model/task/task';

@Injectable({
  providedIn: 'root'
})
export class CrudService {

  // serviceURL : string ;
  
serviceURL = "http://127.0.0.1:8000/Employee/"
  constructor(private http : HttpClient) {
    
  }

  addTask(employee:any):Observable<User> {
    const body={
      name:employee.name,
      meeting:employee.meeting,
      task_assigned:employee.task_assigned,
      TL_name:employee.TL_name,
      remarks:employee.remarks,
    };
   return this.http.post<User>('http://127.0.0.1:8000/Employee/',body)}

}
