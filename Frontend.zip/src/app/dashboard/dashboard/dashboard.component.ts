import { Component, Input, OnInit } from '@angular/core';
import {CrudService} from '../../service/crud.service';
import {User} from '../../model/task/task';
import { ListComponent } from 'src/app/list/list.component';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  emp=new FormGroup({
    name:new FormControl('',[Validators.required]),
    meeting:new FormControl('',[Validators.required]),
    task_assigned:new FormControl('',[Validators.required]),
    TL_name:new FormControl('',[Validators.required]),
    remarks:new FormControl('',[Validators.required]),
  });
  
  // console.log(this.emp.value);

  post(form:any){
    const dt=JSON.stringify(form.value);
    console.log(dt);
    
    this.http.post("http://127.0.0.1:8000/Employee/",dt,{
      headers:{
        "Content-Type": "application/json",
        'Access-Control-Allow-Origin' : 'http://localhost:4200',
        'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE'
      }
    }).subscribe((result)=>{
      // let nm=JSON.stringify(result);
      console.log(result);
    })
    // console.log(this.emp.value);
    // this.obj.name=this.emp.value.name;
  //   let dt=JSON.stringify(this.emp.value);
  // this.http.post("http://127.0.0.1:8000/Employee/",dt,
    // headers:{
    //   "Content-types":"application/json"
    // }
    // const body: JSON.stringify(this.emp)
  //  ).subscribe((result)=>{
  //     alert("Employee Add Successful");
  //     // alert(result.toString());
  //     console.log('result',result);
  //     console.log(JSON.stringify(this.emp));
      
      

    // })
    // console.log(this.register.value);
    this.emp.reset();
    this.router.navigate(['/dashboard']);
    // var json=JSON.stringify(this.emp);

  }
  // {
  //  this.http.post('http://127.0.0.1:8000/Employee/',this.emp,{
  //   headers:{
  //     "Content-types":"application/json"
  //   }
  //   // const body: JSON.stringify(this.emp)
  //  }).subscribe((result)=>{
  //     alert("Employee Add Successful");
  //     // alert(result.toString());
  //     console.log('result',result);
  //   })
  //   // console.log(this.register.value);
  //   this.emp.reset();
  //   this.router.navigate(['/dashboard']);
    
  

  
  constructor(private crudService : CrudService,private http:HttpClient,private router:Router) { }

  ngOnInit(): void {
    // this.post();
  }
}
