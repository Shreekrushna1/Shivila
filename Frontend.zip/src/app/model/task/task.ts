export class User {
    Name='';
    Email='';
    Leave='';
    L_Time='';
    J_Time='';
    Description='';
}
