import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, OnInit, ViewChild,Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {DashboardComponent} from'../dashboard/dashboard/dashboard.component';
import { User } from '../model/task/task';
import { CrudService } from '../service/crud.service';


@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  list=new FormGroup({
    employee_name:new FormControl('',Validators.required),
    employee_email:new FormControl('',Validators.required),
    leave_type:new FormControl('',Validators.required),
    from_leave:new FormControl('',Validators.required),
    to_leave:new FormControl('',Validators.required),
    details:new FormControl('',Validators.required),
    team_lead_name:new FormControl('',Validators.required),
  })
post(){
 
  // let dt=JSON.stringify();
  console.log(this.list.value);
  this.http.post('http://127.0.0.1:8000/abscent/Leavemange/',this.list.value).subscribe((result)=>{
    console.log('result',result);
    
  })
  
}
  constructor(private http:HttpClient) { }
  
  ngOnInit(): void {
  }

}
