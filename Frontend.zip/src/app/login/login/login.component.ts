import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';


import { DashboardComponent } from 'src/app/dashboard/dashboard/dashboard.component';
import { CrudService } from 'src/app/service/crud.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // username:any='sk';
  // password:any='sk';
  
  loginForm=new FormGroup({
    username:new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required])
  })
  
validate(){
  
  this.http.get<any>("http://localhost:3000/register").subscribe(res=>{
    const user=res.find((a:any)=>{
      return a.username===this.loginForm.value.username && a.password===this.loginForm.value.password
    });
    if(user){
      alert("Login Successful");
      // window.alert(this.loginForm.value.username);
      // this.loginForm.value.username;
      this.loginForm.reset();
      this.router.navigate(['/dashboard']);
    }else{
      alert("User Not Found Please Register");
    }
  })
}
  constructor(private router:Router,private crudService:CrudService,private http:HttpClient) { }

  ngOnInit(): void {
  }

}
