import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard/dashboard.component';
import { ListComponent } from './list/list.component';
import { LoginComponent } from './login/login/login.component';
import { NewEmployeeComponent } from './new-employee/new-employee.component';
import { RegisterComponent } from './register/register.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { TLComponent } from './tl/tl.component';

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'dashboard',component:DashboardComponent},
  {path:'list',component:ListComponent},
  {path:'register',component:RegisterComponent},
  {path:'add',component:NewEmployeeComponent},
  {path:'tl',component:TLComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
